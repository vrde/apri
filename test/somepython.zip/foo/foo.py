def bar():
    print 'bar'

if __name__=='__main__':
    bar()

